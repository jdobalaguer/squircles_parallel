
Pour demarrer l'experience
	1\ Aller sur le dossier "squircles_paris"
	2\ Executer:

	>> squircles_paris

Pour arreter l'experience:
	Clicker sur 'Escape' au moment de la r�ponse

Pour demarrer une nouvelle experience
	>> clear all
	>> squircles_paris

Pour continuer une experience:
	Si les variables n'ont pas ete effacees
	>> squircles_paris

	Si les variables ont ete effacees
	>> load data\.... (le fichier qu'on veut continuer)
	>> squircles_paris
	
Les analyses demarrent automatiquement a la fin de l'experience.

