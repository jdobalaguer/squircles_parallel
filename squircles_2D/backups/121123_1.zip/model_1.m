function Rcat = model_1(C,S)
    % we take the most extreme value as a representant of the 
    
    % C = color [0 : 1]
    % S = shape [1 : 2]

    nC = 2 * (C - .5);
    nS = 2 * (S - 1.5);
    
    % nC = new color [-1 : +1]
    % nS = new shape [-1 : +1]
    
    isV = logical(C.*S);
    nV = nC .* nS;
    nV(~isV) = 0; % all that are outside the setsize have value 0 (dummy)
    
    % nV = new value [-1 : +1]
    [~,i_R] = max(abs(nV));
    Rcat = sign(nV(8*(0:749) + i_R));
end
