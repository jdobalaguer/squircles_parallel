clear all
close all

%% LOAD

% subjects' file names
lsdata = regexp(ls('data'),'\s','split');
lsdata(end) = [];

% initialize variables
load(['data/',lsdata{1}]);
nb_psych = max(data.psych);
nb_means = length(variables.means);
nb_subjects = length(lsdata);
nb_conditions = size(conditions,1);
nb_trials = nb_conditions/(nb_means*nb_psych);

% loading cor
cor = zeros(nb_psych,nb_means,nb_subjects,nb_trials);
respcat = zeros(nb_psych,nb_means,nb_subjects,nb_trials);
rt = zeros(nb_psych,nb_means,nb_subjects,nb_trials);
for i_subjects = 1:nb_subjects
    % load
    load(['data/',lsdata{i_subjects}]);
    % store cor
    for i_psych = 1:nb_psych
        for i_mean = 1:nb_means
            % pcor
            cor(i_psych,i_mean,i_subjects,:)     = data.cor(data.psych==i_psych & data.Ms==variables.means(i_mean));
            respcat(i_psych,i_mean,i_subjects,:) = data.respcat(data.psych==i_psych & data.Ms==variables.means(i_mean));
        end
    end
end
mcor = mean(cor,4);
mmcor = mean(mcor,3);

%% ANOVA
d = zeros(nb_subjects,nb_means*nb_psych);
for i_subjects = 1:nb_subjects
    d_subject = mcor(:,:,i_subjects);
    d(i_subjects,:) = d_subject(:);
end
D = [5,3,2];
repanova(d,D);

%% psych plots
u_setsize       = unique(psych(:,1));
u_variance      = unique(psych(:,2));
u_constraint    = unique(psych(:,3));
u_timing        = unique(psych(:,4));

% setsize
psych_setsize = [];
for iu_setsize = 1:length(u_setsize)
    % average of all psych curves with this setsize
    tmp_mmcor = mmcor(u_setsize(iu_setsize)==psych(:,1),:);
    if size(tmp_mmcor,1)>1
        tmp_mmcor = mean(tmp_mmcor);
    end
    % store mcor
    psych_setsize(end+1,:) = tmp_mmcor;
end
figure;
plot(variables.means,psych_setsize')

% variance
psych_variance = [];
for iu_variance = 1:length(u_variance)
    % average of all psych curves with this variance
    tmp_mmcor = mmcor(u_variance(iu_variance)==psych(:,2),:);
    if size(tmp_mmcor,1)>1
        tmp_mmcor = mean(tmp_mmcor);
    end
    % store mcor
    psych_variance(end+1,:) = tmp_mmcor;
end
figure;
plot(variables.means,psych_variance)

% constraint
psych_constraint = [];
for iu_constraint = 1:length(u_constraint)
    % average of all psych curves with this constraint
    tmp_mmcor = mmcor(u_constraint(iu_constraint)==psych(:,3),:);
    if size(tmp_mmcor,1)>1
        tmp_mmcor = mean(tmp_mmcor);
    end
    % store mcor
    psych_constraint(end+1,:) = tmp_mmcor;
end
figure;
plot(variables.means,psych_constraint)

% timing
psych_timing = [];
for iu_timing = 1:length(u_timing)
    % average of all psych curves with this timing
    tmp_mmcor = mmcor(u_timing(iu_timing)==psych(:,4),:);
    if size(tmp_mmcor,1)>1
        tmp_mmcor = mean(tmp_mmcor);
    end
    % store mcor
    psych_timing(end+1,:) = tmp_mmcor;
end
figure;
plot(variables.means,psych_timing)
