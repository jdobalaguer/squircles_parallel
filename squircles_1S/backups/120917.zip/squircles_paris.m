% squircles_paris

    % notes
    %{
        single stimulus feature (shape)
        staircase momentum (mean)
            - convergence for 80% performance
            - intermingled conditions/staircases
        staircases defined by conditions
            - independent momentum (variance)
            - set size
            - constrained/unconstrained sampling
            - time exposition
            - starting from the harder case (d'=0)
        answers only after stimuli exposition
    %}
    
    %% initialization =====================================================
    
    % if a configuration file, run it!
    if exist('config.m','file')
        config();
    end
    
    %% variables
    if ~exist('variables','var')
        variables = struct();
        % conditions
        variables.setsizes      = [4,12];%[4,8,12];
        variables.timings       = [0.2000,0.2639,0.3482,0.4595,0.6063,0.8000];
        variables.variances     = .2;%[0,0.1,0.2];
        variables.constraints   = 0;%[0,1];
        variables.mc            = 0;
        variables.vc            = 0.2;
    end
    max_setsizes = max(variables.setsizes);

    %% conditions matrix
    % [ntrial,i_condition,setsize,timing,variance,constraint]
    if ~exist('conditions','var')
        conditions = [];
        i_condition = 0;
        for setsize = variables.setsizes
            for variance = variables.variances
                for constraint = variables.constraints
                    for timing = variables.timings
                        % condition
                        i_condition = i_condition + 1;
                        % condition matrix
                        condition = [i_condition,setsize,variance,constraint,timing];
                        % trials matrix
                        conditions = [conditions ; condition];
                    end
                end
            end
        end
    end
    nb_conditions = max(conditions(:,1));
    l_blocks      = length(variables.timings);
    nb_blocks     = nb_conditions/l_blocks;
    
    %% convergence
    if ~exist('convergence','var')
        convergence = struct();
        convergence.targetacc       = .80;                                 % staircase performance convergence value
        convergence.top             = 0.3;                                 % maximum value for each sample
        convergence.max             = convergence.top - conditions(:,3);   % maximum value for the staircase
        convergence.min             = 0 * ones(1,nb_conditions);           % minimum value for the staircase
        convergence.step            = 0.1;
        convergence.reset           = .25* ones(1,nb_conditions);          % reset value
        convergence.staircase       = convergence.reset;                   % staircase value
        convergence.nb_trials       = zeros(1,nb_conditions);              % number of trials
        convergence.c_detections    = [1,0,1];                             % detections to use
        convergence.r_detections    = [1,1];                               % detections to use
        % first detection (queue variance)
        convergence.nqueue      = 20;                                      % number of last trials to use
        convergence.relvar      = .005;                                    % maximum relative variance
        % second detection (number of oscillations)
        convergence.nosc        = 8;                                       % number of local maxima/minima
        % third detection (performance ratio)
        convergence.nratio      = 10;                                      % number of last trials to use
        convergence.dtargetacc  = 0.10;                                    % maximum error in performance ratio
        convergence.i_start     = zeros(1,nb_conditions);                  % log index for staircase start position
        convergence.i_reset     = cell(1,nb_conditions);                   % log indexes for staircase reset positions
        convergence.log         = cell(1,nb_conditions);                   % all values in staircases
        convergence.converged   = zeros(1,nb_conditions);                  % has converged
        convergence.limits      = zeros(1,nb_conditions);                  % limit values for the convergence
        convergence.pimits      = zeros(1,nb_conditions);                  % limit values for the performances
        convergence.timings     = zeros(1,nb_conditions);                  % timings (again)
    end
    
    %% participant
    if ~exist('participant','var')
        participant = struct();
        participant.name = input('Nom: ','s');
        participant.age = input('Age: ','s');
        participant.sex = input('Sexe: ','s');
        participant.hand = input('Droitier: ','s');
        participant.subject = Randi(1000);
        participant.filename = sprintf('data%ssquirclesstaircase_%s_%s.mat',filesep,datestr(now,'yyyymmddTHHMMSS'),participant.name);
    end
    
    %% experiment
    if ~exist('experiment','var')
        experiment = struct();
        experiment.task = 'shape';                                         % task
        experiment.varying = 'ms';                                         % staircase value is shape mean
        experiment.audio = 1;                                              % feedback audio
        experiment.text = 0;                                               % feedback text
        experiment.SR = 1;                                                 % mouse button
        experiment.fixdur = .3;                                            % fixation duration (seconds)
        experiment.maskdur = .3;                                           % mask duration
        experiment.maskvar = 100;                                          % mask color variance
        experiment.pausedur = 0;
        experiment.date_start = datestr(now,'yyyymmddTHHMMSS');            % start time
        experiment.startexp = [];
        experiment.endexp = [];
        experiment.ttmin = 0;
        % response keys
        switch(experiment.SR)
            case 1
                experiment.keyleft = 1;
                experiment.keyright = 3;
            case 2
                experiment.keyleft=3;
                experiment.keyright=1;
        end
    end
    tic;                                                                   % timing
    rand('state',sum(100*clock));                                          % random seed
    
    
    %% stimulus
    if ~exist('stimulus','var')
        stimulus = struct();
        stimulus.tiny      = 5;                                            % fixation size
        stimulus.radi      = 200;                                          % radius
        stimulus.rndtheta  = 0;                                            % random locations
        stimulus.rndnstim  = 10;                                           % max nstims to use rand locations
        stimulus.mindtheta = 22.5;                                         % minimum angle distance for rand loc stimuli
        stimulus.harea     = 2500;                                         % area of stimulus (is constant)
        stimulus.whitecol  = RGBcor(1,1);                                  % white color
        stimulus.lumiBG    = .2;                                           % background luminance
        stimulus.bgcol     = RGBcor(1,stimulus.lumiBG);                    % background color
        stimulus.lumiIM    = .09;                                          % luminance of each item
        stimulus.crange    = [0.05 0.95];                                  % c=0 blue    -> c=1 red
        stimulus.srange    = [1.05 1.95];                                  % s=1 square  -> s=2 circle
    end
    
    %% save
    if exist(participant.filename,'file')
        fprintf('squircles_paris: warning: file already used. not saving.');
    else
        save(participant.filename)
    end

    
    %% task ===============================================================
    
    try
        %% open window
        if ~isfield(stimulus,'rect')
            [w, rect] = Screen('OpenWindow', 0, 0,[],32,2);
            stimulus.rect = rect;
        else
            [w, rect] = Screen('OpenWindow', 0, 0,stimulus.rect,32,2);
        end
        Screen(w,'BlendFunction',GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        HideCursor;
        Screen('TextFont', w, 'Helvetica');
        Screen('TextSize', w , 16 );
        center = [rect(3)/2 rect(4)/2];                                    % screen center
        tinyrect = [center-stimulus.tiny, center+stimulus.tiny];           % fixation rect
        KbName('UnifyKeyNames')

        %% instructions
        Screen(w,'FillRect',stimulus.bgcol);
        switch(experiment.SR)
            case 1
                Screen(w,'DrawText','CARRE (boutton gauche) ou CERCLE (boutton droit)',      300,350,            stimulus.whitecol);
            case 2
                Screen(w,'DrawText','CERCLE (boutton gauche) ou CARRE (boutton droit)',      300,350,            stimulus.whitecol);
        end
        xcoords = ((1:11) - 5.5)*50 +  rect(3)/2;
        for k = 1:11
            switch(experiment.SR)
                case 1
                    s = 1+(k-1)/10;
                case 2
                    s = 1+(11-k)/10;
            end
            Ht = 0 : (2*pi/180) : (2*pi);                                  % shapes are defined by parametric curves of Ht (angle)
            Hr = 45*pi/180;                                                % the rotation of the hyperellipse
            Ha = sqrt(abs(1500./4.*gamma(1.+2./s)./(gamma(1.+1./s)).^2));  % define the parameter a from the expected area + curvature S(n)
            Hx = abs(cos(Ht)).^(2./s).*Ha.*sign(cos(Ht));                  % x coordinates
            Hy = abs(sin(Ht)).^(2./s).*Ha.*sign(sin(Ht));                  % y coordinates
            Hc = [0.5 0 0.5];                                              % color
            Hpoly = [Hx*cos(Hr)-Hy*sin(Hr) + xcoords(k) ; Hx*sin(Hr)+Hy*cos(Hr) + 425]';
            RGBcolor = RGBcor(Hc,stimulus.lumiIM);
            Screen('FillPoly', w, RGBcolor, Hpoly, 1);
        end
        Screen(w,'DrawText','Bonjour et merci de votre participation!',                             200,100,   stimulus.whitecol);
        Screen(w,'DrawText','A continuation on vous presentera des figures colorees.',              200,150,   stimulus.whitecol);
        Screen(w,'DrawText','Vous devrez juger au plus vite possible la valeure moyenne des formes',200,200,   stimulus.whitecol);
        Screen(w,'DrawText','et dire a chaque essai si celle-ci est plutot...',                     200,250,   stimulus.whitecol);
        Screen(w,'DrawText','Vous ecouterez un ton aigu lorsque la reponse sera correcte',          200,500,   stimulus.whitecol);
        Screen(w,'DrawText','et un ton grave lorsqu''elle sera incorrecte.',                        200,550,   stimulus.whitecol);
        Screen(w,'DrawText','Vous devrez utiliser ce feedback pour apprendre a repondre au mieux.', 200,600,   stimulus.whitecol);
        Screen(w,'DrawText','Click pour continuer.',                                                200,700,   stimulus.whitecol);
        Screen(w,'Flip');       
        buttons = 0;
        while ~any(buttons)
            [x_mouse,y_mouse,buttons]=GetMouse;
        end
        WaitSecs(0.5);

        %% create mask texture
        stim_r = sqrt(.3183 * stimulus.harea);
        [circle_x,circle_y] = meshgrid(rect(1):rect(3),rect(2):rect(4));
        circle_d = sqrt((circle_x-center(1)).^2 + (circle_y-center(2)).^2); % distance matrix
        r_min = stimulus.radi - stim_r;                                     % annulus min radius
        r_max = stimulus.radi + stim_r;                                     % annulus max radius
        circle_a = 255*(circle_d<r_min | circle_d>r_max);                   % alpha (circular) layer
        
        %% blank wait
        Screen(w,'Flip');       
        buttons = 0;
        while ~any(buttons)
            [x_mouse,y_mouse,buttons]=GetMouse;
        end
        WaitSecs(0.5);
        
        %% create data struct
        if ~exist('data','var')
            data = struct();
            data.sub          = [];
            data.i_trial      = 0;
            data.i_block      = 0;
            data.block        = 0;
            data.i_blockconds = [];
            data.blocks_done  = zeros(1,nb_blocks);
            data.RT           = [];
            data.cor          = [];
            data.cors         = cell(1,nb_conditions);
            data.mcors        = cell(1,nb_conditions);
            data.err          = [];
            data.Mc           = [];
            data.Ms           = [];
            data.Vc           = [];
            data.Vs           = [];
            data.tasknum      = [];
            data.setsize      = [];
            data.C            = [];
            data.S            = [];
            data.Ccat         = [];
            data.Scat         = [];
            data.SR           = [];
            data.theta        = [];
            data.fix_terror   = [];
            data.stim_terror  = [];
            data.mask_terror  = [];
            data.pause_terror = [];
            data.stimcat      = [];
            data.respcat      = [];
            data.respcode     = [];
            data.staircase    = [];
            data.staircases   = cell(1,nb_conditions);
            for i_staircase = 1:length(convergence.staircase)
                data.staircases{i_staircase} = convergence.staircase(i_staircase);
            end
            data.condition   = [];
        end
        
        %% here we go
        experiment.startexp(end+1) = GetSecs;
        getout = 0;
        % wait for convergence and homogeneous number of trials
        i_block = data.i_block;
        i_trial = data.i_trial;
        while 1
            
            % new block
            if all(convergence.converged(data.i_blockconds))
                % end of block
                if data.block
                    data.blocks_done(data.block) = 1;
                end
                % end of experiment
                if all(data.blocks_done)
                    break;
                end
                % new block
                data.block = Randi(nb_blocks);
                while data.blocks_done(data.block)
                    data.block = Randi(nb_blocks);
                end
                i_block = i_block + 1;
                data.i_block = i_block;
                % new trial
                data.i_blockconds = (l_blocks*(data.block-1)+1):(l_blocks*data.block);
                % block screen 1
                Screen(w,'DrawText',['Block ',num2str(i_block)],    center(1)-100,  center(2)     );
                Screen(w,'Flip');
                buttons = 0;
                while ~any(buttons)
                    [x_mouse,y_mouse,buttons] = GetMouse;
                end
                WaitSecs(0.5);
                % block screen 1
                Screen(w,'DrawText',['Block ',num2str(i_block)],    center(1)-100,  center(2)     );
                Screen(w,'DrawText', 'Appuyez pour commencer'  ,    center(1)-100,  center(2)+200 );
                Screen(w,'Flip');
                buttons = 0;
                while ~any(buttons)
                    [x_mouse,y_mouse,buttons] = GetMouse;
                end
                WaitSecs(0.5);
            end
            
            % new trial
            i_trial = i_trial+1;
            
            % conditions --------------------------------------------------
            % pick randomly one of the conditions with less trials
            min_nbtrials = min(convergence.nb_trials(data.i_blockconds));
            i_conditions = find(convergence.nb_trials(data.i_blockconds) == min_nbtrials);
            i_conditions = data.i_blockconds(i_conditions(Randi(length(i_conditions))));
            % set values
            nstims = conditions(i_conditions,2);
            stimdur = conditions(i_conditions,5);
            mc = variables.mc;
            vc = variables.vc;
            ms = convergence.staircase(conditions(i_conditions,1));
            vs = conditions(i_conditions,3);
            constraint = conditions(i_conditions,4);
            
            % stimulus ----------------------------------------------------
            % positions of the stimuli on the screen
            if stimulus.rndtheta && nstims<stimulus.rndnstim
                sort_theta = [1,1];
                while any(diff(sort_theta) < stimulus.mindtheta)
                    theta = 360*rand(1,nstims);
                    sort_theta = [sort(theta),0];
                    sort_theta(end) = sort_theta(1)+360;
                end
            else
                theta = linspace(0,360,nstims+1);
                theta = theta(1:end-1);
            end
            x        = sin(theta*pi/180);
            y        = cos(theta*pi/180);
            % decide stimulus category
            Ccat = sign(rand-0.5); % color
            Scat = sign(rand-0.5); % shape
            % actual values for color and shape
            %                      mean          var     nitems  constraint    critmean    critsd    range              nsamples
            C = mypseudorandrange( 0.5+Ccat*mc,  vc,     nstims, constraint,   0.001,      0.001,    stimulus.crange,   1);
            S = mypseudorandrange( 1.5+Scat*ms,  vs,     nstims, constraint,   0.001,      0.001,    stimulus.srange,   1);

            % fixation ----------------------------------------------------
            Screen(w,'FillRect',stimulus.bgcol);
            Screen(w,'FillOval',stimulus.whitecol,tinyrect);
            [VBLTimestamp,StimulusOnsetTime] = Screen(w,'Flip'); % show fixation
            when = StimulusOnsetTime + experiment.fixdur;

            % exposition -------------------------------------------------
            % graphical construction
            Harea = stimulus.harea;          % area is kept constant for all shapes
            Ht = 0:(2*pi/180):(2*pi);   % shapes are defined by parametric curves of Ht (angle)
            Hr = 45*pi/180;             % the rotation of the hyperellipse
            for n = 1:nstims
                Ha = sqrt(abs(Harea./4.*gamma(1.+2./S(n))./(gamma(1.+1./S(n))).^2)); % define the parameter a from the expected area + curvature S(n)
                Hx = abs(cos(Ht)).^(2./S(n)).*Ha.*sign(cos(Ht));                     % x coordinates
                Hy = abs(sin(Ht)).^(2./S(n)).*Ha.*sign(sin(Ht));                     % y coordinates
                Hc = [C(n) 0 1-C(n)];                                                % color
                Hpoly = [Hx*cos(Hr)-Hy*sin(Hr) + center(1)+stimulus.radi*x(n) ; Hx*sin(Hr)+Hy*cos(Hr) + center(2)+stimulus.radi*y(n)]';
                Screen('FillPoly',w,RGBcor(Hc,stimulus.lumiIM),Hpoly,1);
            end
            % fixation
            Screen(w,'FillOval',stimulus.whitecol,tinyrect);
            [VBLTimestamp,StimulusOnsetTime] = Screen(w,'Flip',when); % show stimulus
            fix_terror = StimulusOnsetTime - when;  % fixation time error
            when = StimulusOnsetTime + stimdur;
            
            % masking -----------------------------------------------------
            % noise
            rectsize = [rect(3)-rect(1),rect(4)-rect(2)];
            noiseimg1 = (experiment.maskvar*randn(rectsize(1),rectsize(2)) + 128);
            noiseimg2 = zeros(rectsize(1),rectsize(2));
            noiseimg3 = (experiment.maskvar*randn(rectsize(1),rectsize(2)) + 128);
            noiseimg(:,:,1) = noiseimg1;
            noiseimg(:,:,2) = noiseimg2;
            noiseimg(:,:,3) = noiseimg3;
            mtex = Screen('MakeTexture', w, noiseimg);
            Screen('DrawTexture', w, mtex, [], rect, [], 0);
            Screen('Close', mtex);
            % alpha circle
            circleimg = stimulus.bgcol(1)*ones(size(circle_d));                 % color (background) layer. has to be greyscale!!
            circleimg(:,:,2) = circle_a;                                        % alpha (circular) layer
            ctex = Screen('MakeTexture', w, circleimg);
            Screen('DrawTexture', w, ctex, [], rect, [], 0);
            Screen('Close', ctex);
            % fixation
            Screen(w,'FillOval',stimulus.whitecol,tinyrect);
            % flip
            [VBLTimestamp,StimulusOnsetTime] = Screen(w,'Flip',when); % show masking
            stim_terror = StimulusOnsetTime - when;
            when = StimulusOnsetTime + experiment.maskdur;

            % pause -------------------------------------------------------
            [VBLTimestamp,StimulusOnsetTime] = Screen(w,'Flip',when); % show masking
            mask_terror = StimulusOnsetTime - when;
            when = GetSecs + experiment.pausedur;
            
            % response ---------------------------------------------------
            %Screen(w,'DrawText','Reponse?', 200,400, stimulus.whitecol);
            Screen(w,'DrawText',[num2str(sum(convergence.converged(data.i_blockconds) > 0)),'/',num2str(l_blocks)],center(1),rect(4)-200);
            %Screen(w,'DrawText',num2str(i_trial/l_blocks),center(1),rect(4)-100);
            [VBLTimestamp,StimulusOnsetTime] = Screen(w,'Flip',when); % show masking
            pause_terror = StimulusOnsetTime - when;
            respcode = [];
            RT = [];
            startresp = GetSecs;
            while isempty(respcode)
                [kdown,ksecs,codes] = KbCheck();
                [x_mouse,y_mouse,buttons] = GetMouse();
                % check escape key
                if kdown && codes(27)
                    getout = 1;
                    break
                end
                % check mouse
                if any(buttons([1,3]))
                    respcode = find(buttons,1);
                    RT = GetSecs-startresp;
                end           
            end
            if getout
                break
            end
            disp(['trial ', num2str(i_trial), '\t -- key ',num2str(respcode),', \t',num2str(RT),' s']);

            % accuracy and feedback ---------------------------------------
            % accuracy
            if isempty(respcode);
                respcode = 0;
                cor = 0;
                RT = 0;
            else
                switch(experiment.task)
                    case 'color'
                        % correct
                        cor = (Ccat==1 && respcode==experiment.keyright) || (Ccat==-1 && respcode==experiment.keyleft);   % red=left,  blue=right
                    case 'shape'
                        % correct
                        cor = (Scat==1 && respcode==experiment.keyright) || (Scat==-1 && respcode==experiment.keyleft);   % vert=left, horz=right
                end
            end
            % auditory feedback
            if experiment.audio
                if cor==1
                    note2(1200,0.1);
                else
                    note2(400,0.1);
                end
            end
            % visual feedback
            if experiment.text
                if cor==1
                    Screen(w,'DrawText','YES',center(1),center(2));
                else
                    Screen(w,'DrawText','NO',center(1),center(2));
                end
            end
            Screen(w,'Flip');

            % staircase ---------------------------------------------------
            mu = staircaseASA(  ...
                data.staircases{conditions(i_conditions,1)},   ...    % int_list
                [data.cors{conditions(i_conditions,1)} , cor], ...    % resp_list
                convergence.targetacc,                         ...    % threshold
                .05 ,                                          ...    % step init
                .01                                            ...    % step_stop
                );
            % check
            if mu > convergence.max
                mu = convergence.max(conditions(i_conditions,1));
            elseif mu < convergence.min
                mu = convergence.min(conditions(i_conditions,1));
            end
            % save new staircase
            convergence.staircase(conditions(i_conditions,1)) = mu;
            
            % convergence -------------------------------------------------
            if ~convergence.converged(conditions(i_conditions,1))
                this_staircase = [data.staircases{conditions(i_conditions,1)},mu];
                length_thisstaircase = length(this_staircase);
                % first condition
                first_detection = 0;
                if length_thisstaircase >= convergence.nqueue
                    i_queuethisstaircase = length_thisstaircase - convergence.nqueue + 1;
                    queue_thisstaircase = this_staircase(i_queuethisstaircase : end);
                    step_thisstaircase = mean(abs(diff(queue_thisstaircase)));
                    if var(queue_thisstaircase) < convergence.relvar*step_thisstaircase
                        first_detection = 1;
                    end
                end
                % second_condition
                second_detection = 0;
                nosc = 0;
                for i_thisstaircase = 2:(length_thisstaircase-1)
                    % local minima
                    if this_staircase(i_thisstaircase) > this_staircase(i_thisstaircase-1) && ...
                       this_staircase(i_thisstaircase) > this_staircase(i_thisstaircase+1)
                        nosc = nosc+1;
                    end
                    % local maxima
                    if this_staircase(i_thisstaircase) < this_staircase(i_thisstaircase-1) && ...
                       this_staircase(i_thisstaircase) < this_staircase(i_thisstaircase+1)
                        nosc = nosc+1;
                    end
                end
                if nosc > convergence.nosc
                    second_detection = 1;
                end
                % third condition
                third_detection = 0;
                this_cor = [data.cors{(conditions(i_conditions,1))},cor];
                if length(this_staircase) > convergence.nratio
                    length_thiscor = length(this_cor);
                    i_ratiothiscor = length_thiscor - convergence.nratio + 1;
                    ratio_thiscor = this_cor(i_ratiothiscor : end);
                    mcor = mean(ratio_thiscor);
                    if abs(mcor-convergence.targetacc) < convergence.dtargetacc
                        third_detection = 1;
                    end
                else
                    mcor = mean(this_cor);
                end
                % set convergence
                if   (~convergence.c_detections(1) || first_detection ) ...
                  && (~convergence.c_detections(2) || second_detection) ...
                  && (~convergence.c_detections(3) || third_detection )
                    convergence.converged(conditions(i_conditions,1)) = length_thisstaircase;
                    convergence.limits(conditions(i_conditions,1)) = geomean(queue_thisstaircase);
                    convergence.pimits(conditions(i_conditions,1)) = mcor;
                    convergence.timings(conditions(i_conditions,1)) = stimdur;
                end
            end
            
            % log data ----------------------------------------------------
            data.sub(i_trial)          = participant.subject;              % subject
            data.i_trial               = i_trial;                          % trial number
            data.RT(i_trial)           = RT;                               % reaction times
            data.cor(i_trial)          = cor;                              % correct
            data.cors{conditions(i_conditions,1)}(end+1) = cor;            % corrects (for each condition)
            data.mcors{conditions(i_conditions,1)}(end+1) = mcor;          % corrects (twindow average)
            data.err(i_trial)          = 1-cor;                            % error
            data.Mc(i_trial)           = mc;                               % mean/color
            data.Ms(i_trial)           = ms;                               % mean/shape
            data.Vc(i_trial)           = vc;                               % var /color
            data.Vs(i_trial)           = vs;                               % var /shape
            data.tasknum(i_trial)      = strcmp(experiment.task,'shape');  % 0='color', 1='shape'
            data.setsize(i_trial)      = nstims;                           % nstims (constant)
            data.C(1:nstims,i_trial)   = C;                                % color value
            data.S(1:nstims,i_trial)   = S;                                % shape value
            data.Ccat(i_trial)         = Ccat;                             % -1=categ1 (blue),   1=categ2 (red)
            data.Scat(i_trial)         = Scat;                             % -1=categ1 (square), 1=categ2 (circle)
            data.SR(i_trial)           = experiment.SR;                    % mouse buttons coding
            data.theta(:,i_trial)  = [theta,zeros(1,max_setsizes-nstims)]; % angle for stimuli
            data.fix_terror(i_trial)   = fix_terror;                       % time flip error in fixation screen
            data.stim_terror(i_trial)  = stim_terror;                      % time flip error in stimulus screen
            data.mask_terror(i_trial)  = mask_terror;                      % time flip error in mask screen
            data.pause_terror(i_trial) = pause_terror;                     % time flip error in pause screen
            data.stimcat(i_trial)      = data.Scat(i_trial).*(data.tasknum(i_trial)==1) + data.Ccat(i_trial).*(data.tasknum(i_trial)==0); % category (for the relevant feature)
            data.respcat(i_trial)      = (respcode-2).*(respcode~=0).*sign(experiment.SR-0.5); % resp = -1 (categ1) or 1 (categ2) or 0 (none)
            data.respcode(i_trial)     = respcode;
            data.staircase(:,i_trial)  = convergence.staircase;            % staircase values
            data.staircases{conditions(i_conditions,1)}(end+1) = convergence.staircase(conditions(i_conditions,1));
            data.condition(i_trial)    = conditions(i_conditions,1);       % condition index
            
            % conditions --------------------------------------------------
            % trial done
            convergence.nb_trials(i_conditions) = convergence.nb_trials(i_conditions)+1;
            
            %% save
            %% ------------------------------------------------------------
            save(participant.filename,'conditions','convergence','data','experiment','participant','stimulus','variables');
        end
    catch e
        save('tmp_error.mat');
        ShowCursor;
        Screen('CloseAll');
        FlushEvents;
        rethrow(e);
    end
    
    %% eoe
    experiment.endexp(end+1) = GetSecs;
    if length(experiment.startexp)==length(experiment.endexp)
        experiment.ttmin = sum(experiment.endexp-experiment.startexp)/60;
    end
    
    %% save
    save(participant.filename,'conditions','convergence','data','experiment','participant','stimulus','variables');
    
    %% finalize
    ShowCursor;
    Screen('CloseAll');
    FlushEvents;
    
    if getout
        return;
    end

%% a posteriori =======================================================
    for i_staircases = 1:length(data.staircases)
        this_relvar = inf;
        for i_staircase = convergence.nqueue : length(data.staircases{i_staircases})
            from_staircase = i_staircase - convergence.nqueue + 1;
            to_staircase = i_staircase;
            queue_thisstaircase = data.staircases{i_staircases}(from_staircase : to_staircase);
            step_thisstaircase = mean(abs(diff(queue_thisstaircase)));
            relvar = var(queue_thisstaircase);%/step_thisstaircase;
            if relvar< this_relvar
                this_relvar = relvar;
                soc = from_staircase;
                eoc = to_staircase;
                moc = geomean(queue_thisstaircase);
                mcor = data.mcors{i_staircases}(eoc-1);
            end
            convergence.converged(i_staircases) = eoc;
            convergence.limits(i_staircases) = moc;
            convergence.pimits(i_staircases) = mcor;
        end
    end

%% plotting ===========================================================
    close all;
    colors = 'bgrcmyk';
    nb_setsizes = length(variables.setsizes);
    nb_timings  = length(variables.timings);
    nb_variances = length(variables.variances);
    nb_constraints = length(variables.constraints);
    
    %% plot convergence curves
    for i_variances = 1:nb_variances
        for i_constraints = 1:nb_constraints
            figure;
            for i_setsizes = 1:nb_setsizes
                for i_timings = 1:nb_timings
                    % subplot
                    subplot(nb_setsizes,nb_timings,(i_setsizes-1)*nb_timings + i_timings);
                    %title(['v=',num2str(variables.variances(i_variances)),',c=',num2str(variables.constraints(i_constraints))]);
                    % average over conditions
                    i_conditions = find(...
                          conditions(:,2)==variables.setsizes(i_setsizes)       ...
                        & conditions(:,3)==variables.variances(i_variances)     ...
                        & conditions(:,4)==variables.constraints(i_constraints) ...
                        & conditions(:,5)==variables.timings(i_timings)         ...
                        );
                    staircase = data.staircases{i_conditions};
                    % plot
                    plot(staircase,'k');
                    if convergence.converged(i_conditions)
                        eoc = convergence.converged(i_conditions);
                        soc = eoc - convergence.nqueue;
                        valley = staircase(soc:eoc);
                        hold on;
                        plot(soc:eoc,valley,'r');
                        plot(1:length(staircase),ones(1,length(staircase))*convergence.limits(i_conditions),'g');
                    end
                end
            end
        end
    end
    
    %% plot mcors curves
    for i_variances = 1:nb_variances
        for i_constraints = 1:nb_constraints
            figure;
            for i_setsizes = 1:nb_setsizes
                for i_timings = 1:nb_timings
                    % subplot
                    subplot(nb_setsizes,nb_timings,(i_setsizes-1)*nb_timings + i_timings);
                    % average over conditions
                    i_conditions = find(...
                          conditions(:,2)==variables.setsizes(i_setsizes)       ...
                        & conditions(:,3)==variables.variances(i_variances)     ...
                        & conditions(:,4)==variables.constraints(i_constraints)   ...
                        & conditions(:,5)==variables.timings(i_timings)         ...
                        );
                    mcors = data.mcors{i_conditions};
                    % plot
                    plot(mcors,'k');
                    if convergence.converged(i_conditions)
                        eoc = convergence.converged(i_conditions) - 1;
                        soc = eoc - convergence.nratio + 1;
                        valley = mcors(soc:eoc);
                        hold on;
                        plot(soc:eoc,valley,'r');
                        plot(1:length(mcors),ones(1,length(mcors))*convergence.pimits(i_conditions),'g');
                    end
                end
            end
        end
    end
    
    %% plot convergence in function of timing
    i_plot = 1;
    mean_conditions = [0,1,1];
    plot_limits = [];
    for i_setsizes = 1:nb_setsizes
        for i_variances = 1:nb_variances
            for i_constraints = 1:nb_constraints
                tmp_timings = [];
                tmp_limits = [];
                for i_timings = 1:nb_timings
                    % average over conditions
                    i_conditions = find(...
                        (mean_conditions(1) | conditions(:,2)==variables.setsizes(i_setsizes))       ...
                        & (mean_conditions(2) | conditions(:,3)==variables.variances(i_variances))     ...
                        & (mean_conditions(3) | conditions(:,4)==variables.constraints(i_constraints)) ...
                        & conditions(:,5)==variables.timings(i_timings)         ...
                        );
                    % get values
                    tmp_timings = [tmp_timings , convergence.timings(i_conditions)'];
                    tmp_limits = [tmp_limits , convergence.limits(i_conditions)'];
                end
                % average over timings
                if size(tmp_timings,1) > 1
                    tmp_timings = mean(tmp_timings);
                    tmp_limits = mean(tmp_limits);
                end
                % change color
                if i_plot > length(colors)
                    i_plot = 1;
                end
                % plot
                plot_limits = [plot_limits ; tmp_limits];
                % increment index
                i_plot = i_plot+1;
            end
        end
    end
    plot_limits = [plot_limits ; zeros(1,nb_timings)];
    plot_limits = unique(plot_limits,'rows');
    figure; plot(    tmp_timings,     plot_limits);
    figure; plot(log(tmp_timings),log(plot_limits));

        %% plot convergence in function of setsize
    i_plot = 1;
    mean_conditions = [1,0,1];
    plot_limits = [];
    for i_timings = 1:nb_timings
        for i_variances = 1:nb_variances
            for i_constraints = 1:nb_constraints
                tmp_setsizes = [];
                tmp_limits = [];
                for i_setsizes = 1:nb_setsizes
                    % average over conditions
                    i_conditions = find(...
                        conditions(:,2)==variables.setsizes(i_setsizes)       ...
                        & (mean_conditions(1) | conditions(:,3)==variables.variances(i_variances))     ...
                        & (mean_conditions(2) | conditions(:,4)==variables.constraints(i_constraints)) ...
                        & (mean_conditions(3) | conditions(:,5)==variables.timings(i_timings))         ...
                        );
                    % get values
                    tmp_setsizes = [tmp_setsizes , variables.setsizes(i_setsizes)*ones(size(i_conditions))];
                    tmp_limits = [tmp_limits , convergence.limits(i_conditions)'];
                end
                % average over setsizes
                if size(tmp_setsizes,1) > 1
                    tmp_setsizes = mean(tmp_setsizes);
                    tmp_limits = mean(tmp_limits);
                end
                % plot
                plot_limits = [plot_limits ; tmp_limits];
            end
        end
    end
    plot_limits = [plot_limits ; zeros(1,nb_setsizes)];
    plot_limits = unique(plot_limits,'rows');
    figure; plot(tmp_setsizes,plot_limits');
