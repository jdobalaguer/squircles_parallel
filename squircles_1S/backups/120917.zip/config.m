variables = struct();
% conditions
variables.setsizes      = [4,8,12];
variables.timings       = [0.2000,0.2639,0.3482,0.4595,0.6063,0.8000];
variables.variances     = [0,0.1,0.2];
variables.constraints   = [0,1];
variables.mc            = 0;	% Mean color
variables.vc            = 0.2;	% SD color